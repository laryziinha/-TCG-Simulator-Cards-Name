This is a script that will allow you to automatically scan through every .ini file in the same folder as it and replace any lines you want with the replacement you choose. 

You can edit the script in notepad or notepad++ as it is just a plain text file

When you open it you will see an example of how to input the lines to be replaced and their replacements

This will allow you to easily make all your config changes everytime a new update is released for the mod so you don't have to manually change things every time

As always make BACKUPS before you try making any changes

To run the script you need Python installed and then you should be able to just click the RunScript.bat