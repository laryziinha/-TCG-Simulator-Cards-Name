import os

# Define the list of lines to replace and their replacements

replacements = {
    "Name Enabled = True": "Name Enabled = False",
    "Description Enabled = True": "Description Enabled = False",
    "Description Enabled = True": "Description Enabled = False",
    "Individual Overrides = False": "Individual Overrides = True",
    "Number Enabled = True": "Number Enabled = False",
    "Basic Evolution Icon Enabled = True": "Basic Evolution Icon Enabled = False",
    "Basic Evolution Text Enabled = True": "Basic Evolution Text Enabled = False",
    "Previous Evolution Icon Enabled = True": "Previous Evolution Icon Enabled = False",
    "Play Effect Text Enabled = True": "Play Effect Text Enabled = False",
    "Rarity Enabled = True": "Rarity Enabled = False",
    "Rarity Image Enabled = True": "Rarity Image Enabled = False",
    "Champion Text Enabled = False": "Champion Text Enabled = False",
    "Stat1 Enabled = True": "Stat1 Enabled = False",
    "Stat2 Enabled = True": "Stat1 Enabled = False",
    "Stat3 Enabled = True": "Stat1 Enabled = False",
    "Stat4 Enabled = True": "Stat1 Enabled = False",
    "Artist Text Enabled = True": "Artist Text Enabled = False",
    "Company Text Enabled = True": "Company Text Enabled = False",
    "Remove Monster Image Size Limit = False": "Remove Monster Image Size Limit = True",
    "Monster Image Size = (0.20, 197.00)": "Monster Image Size = (70., 380.00)",
    "Previous Evolution Box Enabled = True": "Previous Evolution Box Enabled = False",
    "Play Effect Box Enabled = True": "Play Effect Box Enabled = False",
    # Change these with the lines you want to replace and their replacements
}
# Here is an example
#replacements = {
#    "Name = Archer": "Name = Bad Archer",
#    "Name Enabled = True": "Name Enabled = False",
#}

#This is folder the script is in, so it should be in the folder with the .ini files you want to replace text in
folder_path = os.path.dirname(os.path.abspath(__file__))


# Iterate over each .ini file in the folder
for filename in os.listdir(folder_path):
    if filename.endswith(".ini"):
        file_path = os.path.join(folder_path, filename)
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.readlines()

        # Replace lines as per the replacements dictionary
        for i, line in enumerate(content):
            for old_line, new_line in replacements.items():
                if old_line in line:
                    content[i] = line.replace(old_line, new_line)

        # Write the updated content back to the file
        with open(file_path, 'w', encoding='utf-8') as file:
            file.writelines(content)
            print("Done");